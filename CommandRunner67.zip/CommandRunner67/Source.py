try:
    import tkinter
    import os
    import sys
    import subprocess
except ImportError:
    print("Something went wrong while importing. Please restart the file.. noob")

root = tkinter.Tk()
root.title("CMD")
root.geometry("350x375")

Bg = "#000000"   #black
txtclr = "#FFFFFF"
root.configure(bg=Bg)

header = tkinter.Frame(root, bg=Bg)
header.pack(pady=6)

titlererere = tkinter.Label(
    header,
    text="Welcome to: CMD",
    bg=Bg,
    fg=txtclr,
    font=("Arial", 19)
)
titlererere.pack()

noteererere = tkinter.Label(
    header,
    text="Type your command then click enter.",
    bg=Bg,
    fg=txtclr,
    font=("Arial", 10)
)

noteererere2 =   tkinter.Label(
    header,
    text="Also, check your CMDPrompt / Terminal for results.",
    bg=Bg,
    fg=txtclr,
    font=("Arial", 10)
).pack()

noteererere.pack()
cmdprompt = tkinter.Text(root,bg="#333333",fg=txtclr,height=15,width=30)
cmdprompt.pack(pady=15)

def firecmd(event):
    try:
        txt = cmdprompt.get("1.0","end-1c")
        store = txt.split()
        thecmd = " ".join(f'"{v}"' for v in store)
        subprocess.check_call(thecmd)
        print("Running command: ",thecmd)
    except:
        print("Something went wrong.")



cmdprompt.bind("<Return>",firecmd)

root.mainloop()