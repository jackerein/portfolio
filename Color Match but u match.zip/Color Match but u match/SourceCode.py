import tkinter as tk
from random import randint

def rand_hex():
    return "#{:02x}{:02x}{:02x}".format(
        randint(0, 255),
        randint(0, 255),
        randint(0, 255)
    )

root = tk.Tk()
root.title("To Get")
root.geometry("350x350+100+100")
generation = rand_hex()
root.configure(bg=generation)

bleh = tk.Label(root, text="??? [Find first!]")
bleh.pack(pady=12)

upper = tk.Toplevel(root)
upper.title("Generating..")
upper.geometry("220x220")

rn = tk.Entry(upper, text="#FFFF00")
rn.pack(pady=30)

current = "#FFFF00"
upper.configure(bg=current)

def place_next_to_each_other():
    root.update_idletasks()
    upper.update_idletasks()

    x = root.winfo_x()
    y = root.winfo_y()
    w = root.winfo_width()

    gap = 10
    upper.geometry(f"220x220+{x + w + gap}+{y}")

root.after(0, place_next_to_each_other)

def loop():
    def on_enter(event):
        try:
            #(generation)
            upper.configure(bg = rn.get())
            if rn.get() == generation:
                #("goodie")
                bleh.config(text=generation)
        except:
            print("Invalid!")
            


    rn.bind("<Return>", on_enter)

loop()
root.mainloop()
