# Grabs daily wordle word 
try:
    import requests
except ImportError:
    import sys
    import subprocess
    
    print("You are missing module 'requests', my cool code will install it for u.\n rlly required to use the api btw")

    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

import datetime
import tkinter
date = datetime.date.today()
date_str = date.strftime("%Y-%m-%d")

api = f"https://www.nytimes.com/svc/wordle/v2/{date_str}.json"

tmrw = (datetime.date.today() + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
try:
    requested = requests.get(api)
    data = requested.json()

    word = data['solution']
except:
    print("We couldn't get todays Wordle word due to an API error.. Yikes!")
    exit()

# ---- UI ----
uiRoot = tkinter.Tk()
uiRoot.title("Wordle TD")
uiRoot.geometry("260x150")

# Baby blue theme
BG = "#cfe9ff"
FG_MAIN = "#1f4e79"
FG_SUB = "#4f7ca8"

uiRoot.configure(bg=BG)
wordfinder_window = None
def wordfinder():
    global wordfinder_window

    if wordfinder_window is not None and wordfinder_window.winfo_exists():
        wordfinder_window.lift()      # bring it to the front
        wordfinder_window.focus_force()
        return

    wordfinder_window = tkinter.Toplevel()
    wordfinder_window.geometry("240x180")
    wordfinder_window.configure(bg=BG)

    intro = tkinter.Label(wordfinder_window,text="Please enter a date below! [YYYY-MM-DD]",bg=BG,fg=FG_MAIN,font=("Arial Rounded MT Bold", 8)).pack(pady = 10)
    entry = tkinter.Entry(wordfinder_window,bg = BG, fg = FG_SUB)
    entry.pack(pady=10)

    def on_enter(event):
        s.config(text="Please wait..")

        wordfinder_window.update()

        try:
            napi = f"https://www.nytimes.com/svc/wordle/v2/{entry.get()}.json"
            gotten = requests.get(napi)
            tdata = gotten.json()
            s.config(text=f"SOLUTION [WORD]: {tdata['solution']}")
        except:
            s.config(text="API Error")


    entry.bind("<Return>", on_enter)


    s = tkinter.Label(
        wordfinder_window,
        text=f"SOLUTION [WORD]: ???",
        bg=BG,
        fg=FG_MAIN,
        font=("Arial Rounded MT Bold", 12)
    )
    s.pack(pady=6)


    def on_close():
        global wordfinder_window
        wordfinder_window.destroy()
        wordfinder_window = None

    wordfinder_window.protocol("WM_DELETE_WINDOW", on_close)



tkinter.Label(
    uiRoot,
    text=f"SOLUTION [WORD]: {word.upper()}",
    bg=BG,
    fg=FG_MAIN,
    font=("Arial Rounded MT Bold", 12)
).pack(pady=6)

tkinter.Label(
    uiRoot,
    text=f"{date_str} → {tmrw}",
    bg=BG,
    fg=FG_SUB,
    font=("Helvetica", 9)
).pack(pady=6)

tkinter.Button(
    uiRoot,
    text="Find Word for Date",
    command = wordfinder,
    bg = BG,
    fg = FG_SUB
).pack(pady=6)

uiRoot.mainloop()
