# before continuing ur snooping, think about the work ive put into it.. 
# [the code is far down]

# imports are here tho so u know what i use

try:
    import tkinter as tk
    import os
    import sys
    import subprocess
    from plyer import notification
    from PIL import Image, ImageTk
    import winsound
    from random import randint
    from time import sleep
    from datetime import date

except ImportError:
    print("An error happen when importing required modules, I will attempt to download the required non-supplied modules for you.")
    subprocess.check_call([sys.executable,"-m","pip","install","pillow"])
    print("Plyer and pillow are installed, retry and see")
    exit()   #  you cant rlly proceed without these modules..


root = tk.Tk() ; root.title("Random Button") ; root.geometry("300x300") ; root.configure(bg = "#343434")                                                                                              # fuck you sif

print("Loading assets from dir/Photos")

photos = []
sfx = []
badsfx = []
badphoto = []

def sendNoti():
    notification.notify(
        title = "{:02x}{:02x}{:02x}{:05x}{:05x}".format(randint(0,255),randint(0,255),randint(0,255),randint(0,25500),randint(0,25500)),
        message = "{:02x}{:02x}{:02x}{:05x}{:05x}{:02x}{:02x}{:02x}{:05x}{:05x}".format(randint(0,255),randint(0,255),randint(0,255),randint(0,25500),randint(0,25500),randint(0,255),randint(0,255),randint(0,255),randint(0,25500),randint(0,25500)),
        timeout = 1
    )

def closeSelf():
    if randint(1,125) == 25:
        winsound.PlaySound(badsfx[randint(0,len(badsfx)-1)], winsound.SND_FILENAME | winsound.SND_ASYNC)
        thebutton.config(command=None,image=badphoto[randint(0,len(badphoto)-1)],state="disabled")
        root.after(2000,exit)

def create():
    if randint(1,50) == 50:
        with open("{:02x}{:02x}{:03x}.random".format(randint(0,255),randint(0,255),randint(0,2550)), "x") as f:
            f.write("{:02x}{:02x}{:03x}".format(randint(0,255),randint(0,255),randint(0,2550)))

call = {
    "0" : sendNoti,
    "1" : closeSelf,
    "2": create
}

base_dir = os.path.dirname(os.path.abspath(__file__))

try:
    sfx.append(os.path.join(base_dir,"Sounds","cat-meow-401729.wav"))
    sfx.append(os.path.join(base_dir,"Sounds","cat-meow-297927.wav"))
    sfx.append(os.path.join(base_dir,"Sounds","cm3.wav"))
    sfx.append(os.path.join(base_dir,"Sounds","cm4.wav"))
    badsfx.append(os.path.join(base_dir,"Sounds","sad.wav"))
except:
    print("Error while loading sounds, if you modified sound file names, or something like that, change the code too [from line ~33]")

try:
    c1img_path = os.path.join(base_dir, "Photos", "cat-1.png")
    c1img = Image.open(c1img_path)
    c1img = c1img.resize((120,60))
    cat_1 = ImageTk.PhotoImage(c1img)
    photos.append(cat_1)

    c2img_path = os.path.join(base_dir,"Photos","cat_tongue.png")
    c2img = Image.open(c2img_path)
    c2img = c2img.resize((120,60))
    cat_2 = ImageTk.PhotoImage(c2img)
    photos.append(cat_2)

    spimg_path = os.path.join(base_dir,"Photos","spongebob_sad.png")
    spimg = Image.open(spimg_path)
    spimg = spimg.resize((120,60))
    sp = ImageTk.PhotoImage(spimg)
    badphoto.append(sp)

except:
    print("We couldn't load the silly photos correctly.")
    exit()

def response():
    thebutton.config(image=photos[randint(0,len(photos)-1)])
    winsound.PlaySound(sfx[randint(0,len(sfx)-1)], winsound.SND_FILENAME | winsound.SND_ASYNC)
    call[str(randint(0,len(call)-1))]()

thebutton = tk.Button(root,image=photos[randint(0,len(photos)-1)],command=response)
thebutton.pack(pady=50)

thetext = tk.Label(text="Click the button..",bg="#343434",fg="#3388CC",font=("Comic Sans MS",25)).pack()


def poop():
    if randint(1,2) == 2:
        root.title(f"Today is {date.today()}")
    else:
        root.title("Random Button")
    root.after(3000,poop)

poop()

root.mainloop()